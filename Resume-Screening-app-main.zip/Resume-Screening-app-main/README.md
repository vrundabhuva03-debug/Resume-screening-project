# Resume-Screening-app


i have uploaded 1 model and 1 another model is large in size thatswhy skiped.
